﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","uk",{title:"Відомості про Елемент",dialogName:"Заголовок діалогового вікна",tabName:"Назва вкладки",elementId:"Ідентифікатор Елемента",elementType:"Тип Елемента"});